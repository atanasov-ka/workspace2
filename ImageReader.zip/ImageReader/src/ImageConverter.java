import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.imageio.ImageIO;

public class ImageConverter {


	private String convert(int intensity)
	{
	
		 if (intensity > 240) return " ";
		 else if (intensity >200 && intensity < 240) return "*";
		 else if (intensity >160 && intensity < 200) return ".";
		 else if (intensity >120 && intensity < 160) return ".";
		 else if (intensity >40 && intensity < 80) return "#";
		 else return ".";
	}

	public void exec(String string) throws URISyntaxException, IOException {

		Path path = Paths.get(string);
		BufferedImage buffer = ImageIO.read(path.toFile());
		int height = buffer.getHeight();
		int width = buffer.getWidth();
		StringBuilder picture = new StringBuilder();
		for (int i = 0; i < height; ++i) {
			for (int j = 0; j < width; j++) {
				Color c = new Color(buffer.getRGB(j, i), false);
				int intens = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
				picture.append(convert(intens));
			}
			picture.append("\n");
		}
		
		System.out.println(picture.toString());
	}
}
